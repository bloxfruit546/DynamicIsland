#import <UIKit/UIKit.h>
#import "src/DIWindowController.h"
#import "src/DIActivityManager.h"
#import "src/DINotificationProvider.h"
#import "src/DIMusicProvider.h"
#import "src/DICallProvider.h"
#import "src/DITimerProvider.h"
#import "src/DIBatteryProvider.h"
#import "src/DIRingerProvider.h"
#import "src/DIPreferencesManager.h"

// ─────────────────────────────────────────────────────────────
// Hook 1: SpringBoard – Initialize everything on SpringBoard launch
// ─────────────────────────────────────────────────────────────
%hook SpringBoard

- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    @try {
        if (![DIPreferencesManager sharedInstance].isEnabled) return;
        
        [[DIWindowController sharedInstance] setupWindow];
        [[DIMusicProvider sharedInstance] startMonitoring];
        [[DICallProvider sharedInstance] startMonitoring];
        [[DITimerProvider sharedInstance] startMonitoring];
        [[DIBatteryProvider sharedInstance] startMonitoring];
        [[DIRingerProvider sharedInstance] startMonitoring];
        
        NSLog(@"[DynamicIsland] Initialized successfully in SpringBoard (v2.0)");
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] Init exception: %@", e);
    }
}

%end

// ─────────────────────────────────────────────────────────────
// Hook 2: SBNotificationBannerDestination – iOS 12 notifications
// ─────────────────────────────────────────────────────────────
%hook SBNotificationBannerDestination

- (void)postNotificationRequest:(id)request forCoalescedNotification:(id)coalesced {
    %orig;
    @try {
        if (![DIPreferencesManager sharedInstance].isEnabled) return;
        if (![DIPreferencesManager sharedInstance].showNotifications) return;
        
        [[DINotificationProvider sharedInstance] handleBannerRequest:request];
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] SBNotificationBannerDestination exception: %@", e);
    }
}

%end

// ─────────────────────────────────────────────────────────────
// Hook 3: SBBannerController – Legacy / fallback banner hook
// ─────────────────────────────────────────────────────────────
%hook SBBannerController

- (void)observer:(id)observer
    addBannerWithRequest:(id)request
           forAssertion:(id)assertion {
    %orig;
    
    @try {
        if (![DIPreferencesManager sharedInstance].isEnabled) return;
        if (![DIPreferencesManager sharedInstance].showNotifications) return;
        
        [[DINotificationProvider sharedInstance] handleBannerRequest:request];
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] SBBannerController exception: %@", e);
    }
}

%end

// ─────────────────────────────────────────────────────────────
// Hook 4: MPNowPlayingInfoCenter – Music updates
// ─────────────────────────────────────────────────────────────
%hook MPNowPlayingInfoCenter

- (void)setNowPlayingInfo:(NSDictionary *)nowPlayingInfo {
    %orig;
    
    @try {
        if (![DIPreferencesManager sharedInstance].isEnabled) return;
        if (![DIPreferencesManager sharedInstance].showMusic) return;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [[DIMusicProvider sharedInstance] updateWithInfo:nowPlayingInfo];
        });
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] NowPlaying hook exception: %@", e);
    }
}

%end

// ─────────────────────────────────────────────────────────────
// Hook 5: SBLockScreenManager – Hide island when lockscreen active
// ─────────────────────────────────────────────────────────────
%hook SBLockScreenManager

- (void)setIsUILocked:(BOOL)locked {
    %orig;
    @try {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[DIWindowController sharedInstance] setHidden:locked];
        });
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] LockScreen hook exception: %@", e);
    }
}

%end

#import <dlfcn.h>

// ─────────────────────────────────────────────────────────────
// Hook 6: MTTimerManager – System-wide timer interception
// ─────────────────────────────────────────────────────────────
%group MobileTimerHooks
%hook MTTimerManager

- (id)startTimer:(id)timer {
    id res = %orig;
    [DITimerProvider handleTimerEvent:timer state:1];
    return res;
}

- (id)pauseTimer:(id)timer {
    id res = %orig;
    [DITimerProvider handleTimerEvent:timer state:2];
    return res;
}

- (id)resumeTimer:(id)timer {
    id res = %orig;
    [DITimerProvider handleTimerEvent:timer state:1];
    return res;
}

- (id)stopTimer:(id)timer {
    id res = %orig;
    [DITimerProvider handleTimerEvent:timer state:3];
    return res;
}

- (id)updateTimer:(id)timer {
    id res = %orig;
    [DITimerProvider handleTimerEvent:timer state:1];
    return res;
}

- (id)dismissTimerWithIdentifier:(id)arg1 {
    id res = %orig;
    [DITimerProvider handleTimerDismissed];
    return res;
}

%end
%end

// ─────────────────────────────────────────────────────────────
// Constructor – safely initialize hooks per process
// ─────────────────────────────────────────────────────────────
%ctor {
    @autoreleasepool {
        NSString *procName = [[NSProcessInfo processInfo] processName];
        NSLog(@"[DynamicIsland] Tweak loaded into %@", procName);
        
        // Ensure MobileTimer framework is loaded into address space
        dlopen("/System/Library/PrivateFrameworks/MobileTimer.framework/MobileTimer", RTLD_NOW);
        
        if ([procName isEqualToString:@"SpringBoard"]) {
            %init;
            if (objc_getClass("MTTimerManager")) {
                %init(MobileTimerHooks);
            }
        } else if ([procName isEqualToString:@"MobileTimer"] || [procName isEqualToString:@"mobiletimerd"]) {
            if (objc_getClass("MTTimerManager")) {
                %init(MobileTimerHooks);
            }
        }
    }
}
