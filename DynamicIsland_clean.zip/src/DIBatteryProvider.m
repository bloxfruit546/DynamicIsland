#import "DIBatteryProvider.h"
#import "DIActivityManager.h"
#import "DIPreferencesManager.h"

@interface DIBatteryProvider ()
@property (nonatomic, assign) BOOL isCharging;
@property (nonatomic, assign) NSInteger batteryPercentage;
@property (nonatomic, assign) UIDeviceBatteryState lastState;
@end

@implementation DIBatteryProvider

+ (instancetype)sharedInstance {
    static DIBatteryProvider *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isCharging = NO;
        _batteryPercentage = 100;
        _lastState = UIDeviceBatteryStateUnknown;
    }
    return self;
}

- (void)startMonitoring {
    [UIDevice currentDevice].batteryMonitoringEnabled = YES;
    _lastState = [UIDevice currentDevice].batteryState;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(batteryStateChanged:)
                                                 name:UIDeviceBatteryStateDidChangeNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(batteryLevelChanged:)
                                                 name:UIDeviceBatteryLevelDidChangeNotification
                                               object:nil];
}

- (void)stopMonitoring {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)batteryStateChanged:(NSNotification *)note {
    if (![DIPreferencesManager sharedInstance].isEnabled) return;
    if (![DIPreferencesManager sharedInstance].showCharging) return;
    
    UIDeviceBatteryState state = [UIDevice currentDevice].batteryState;
    float level = [UIDevice currentDevice].batteryLevel;
    NSInteger pct = (level < 0) ? 100 : (NSInteger)(level * 100);
    
    // Trigger animation when transitioned into Charging or Full
    if ((state == UIDeviceBatteryStateCharging || state == UIDeviceBatteryStateFull) &&
        (_lastState != UIDeviceBatteryStateCharging && _lastState != UIDeviceBatteryStateFull)) {
        
        _isCharging = YES;
        _batteryPercentage = pct;
        
        DIActivityContent *content = [[DIActivityContent alloc] init];
        content.type      = DIActivityTypeCharging;
        content.isOngoing = NO; // Transient: automatically collapses after 2.5s
        content.title     = [NSString stringWithFormat:@"%ld%%", (long)pct];
        content.subtitle  = @"Charging";
        content.progress  = (pct / 100.0f);
        
        [[DIActivityManager sharedInstance] presentContent:content];
    } else if (state == UIDeviceBatteryStateUnplugged) {
        _isCharging = NO;
    }
    _lastState = state;
}

- (void)batteryLevelChanged:(NSNotification *)note {
    float level = [UIDevice currentDevice].batteryLevel;
    if (level >= 0) {
        _batteryPercentage = (NSInteger)(level * 100);
    }
}

- (void)dealloc {
    [self stopMonitoring];
}

@end
