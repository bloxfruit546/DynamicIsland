#import "DynamicIslandView.h"
#import "DICompactView.h"
#import "DIExpandedView.h"
#import "DIAnimator.h"
#import "DIPreferencesManager.h"

// Layout constants optimized for iPhone 5s (320pt screen width)
static const CGFloat kIdleWidth        = 88.0f;
static const CGFloat kIdleHeight       = 26.0f;
static const CGFloat kIdleRadius       = 13.0f;
static const CGFloat kTopOffset        = 5.0f;

static const CGFloat kCompactWidth     = 160.0f;
static const CGFloat kCompactHeight    = 30.0f;
static const CGFloat kCompactRadius    = 15.0f;

static const CGFloat kExpandedWidth    = 292.0f;
static const CGFloat kExpandedHeight   = 78.0f;
static const CGFloat kExpandedRadius   = 22.0f;

@interface DynamicIslandView ()
@property (nonatomic, strong) DICompactView    *compactView;
@property (nonatomic, strong) DIExpandedView   *expandedView;
@property (nonatomic, assign) DIIslandState     islandState;
@property (nonatomic, weak)   UIView           *parentView;
@end

@implementation DynamicIslandView

- (instancetype)initWithSuperview:(UIView *)superview {
    CGFloat screenW = superview.bounds.size.width;
    if (screenW <= 0) screenW = [UIScreen mainScreen].bounds.size.width;
    
    CGRect initialFrame = CGRectMake(
        (screenW - kIdleWidth) / 2.0f,
        kTopOffset,
        kIdleWidth,
        kIdleHeight
    );
    
    self = [super initWithFrame:initialFrame];
    if (self) {
        _parentView   = superview;
        _islandState  = DIIslandStateIdle;
        [self setupView];
        [self setupGestures];
        [DIActivityManager sharedInstance].delegate = self;
    }
    return self;
}

- (void)setupView {
    self.backgroundColor     = [UIColor blackColor];
    self.layer.cornerRadius  = kIdleRadius;
    self.layer.masksToBounds = NO;
    self.clipsToBounds       = NO;
    
    // Smooth shadow surrounding the island
    self.layer.shadowColor   = [UIColor blackColor].CGColor;
    self.layer.shadowOpacity = 0.45f;
    self.layer.shadowOffset  = CGSizeMake(0, 3);
    self.layer.shadowRadius  = 6;
    
    // Compact view
    _compactView = [[DICompactView alloc] initWithFrame:self.bounds];
    _compactView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _compactView.alpha = 0;
    [self addSubview:_compactView];
    
    // Expanded view (hidden initially)
    _expandedView = [[DIExpandedView alloc] initWithFrame:self.bounds];
    _expandedView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _expandedView.alpha  = 0;
    _expandedView.hidden = YES;
    [self addSubview:_expandedView];
}

- (void)setupGestures {
    // Tap to expand / interact
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                           action:@selector(handleTap:)];
    [self addGestureRecognizer:tap];
    
    // Long press to expand
    UILongPressGestureRecognizer *longPress =
        [[UILongPressGestureRecognizer alloc] initWithTarget:self
                                                      action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = 0.35;
    [self addGestureRecognizer:longPress];
    
    // Swipe down to expand
    UISwipeGestureRecognizer *swipeDown = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                    action:@selector(handleSwipeDown:)];
    swipeDown.direction = UISwipeGestureRecognizerDirectionDown;
    [self addGestureRecognizer:swipeDown];
    
    // Swipes to collapse
    UISwipeGestureRecognizer *swipeUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                  action:@selector(handleSwipeCollapse:)];
    swipeUp.direction = UISwipeGestureRecognizerDirectionUp;
    [self addGestureRecognizer:swipeUp];
    
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                    action:@selector(handleSwipeCollapse:)];
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    [self addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleSwipeCollapse:)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self addGestureRecognizer:swipeRight];
}

#pragma mark - Public API

- (void)showIdle {
    if (_islandState == DIIslandStateIdle) return;
    _islandState = DIIslandStateIdle;
    
    CGFloat screenW = _parentView ? _parentView.bounds.size.width : [UIScreen mainScreen].bounds.size.width;
    CGRect idleFrame = CGRectMake(
        (screenW - kIdleWidth) / 2.0f,
        kTopOffset,
        kIdleWidth,
        kIdleHeight
    );
    
    [DIAnimator fadeOutView:_expandedView completion:^(BOOL f) {
        self.expandedView.hidden = YES;
        [self.expandedView clearContent];
    }];
    [DIAnimator fadeOutView:_compactView completion:^(BOOL f) {
        [self.compactView showDefault];
    }];
    
    [DIAnimator animateView:self toFrame:idleFrame cornerRadius:kIdleRadius completion:nil];
}

- (void)showCompact {
    DIActivityContent *current = [DIActivityManager sharedInstance].currentContent;
    if (current) {
        [self showCompactWithContent:current];
    } else {
        [self showIdle];
    }
}

- (void)showCompactWithContent:(DIActivityContent *)content {
    [self showCompactWithContent:content secondaryContent:nil];
}

- (void)showCompactWithContent:(DIActivityContent *)content secondaryContent:(DIActivityContent *)secondary {
    _islandState = DIIslandStateCompact;
    
    CGFloat screenW = _parentView ? _parentView.bounds.size.width : [UIScreen mainScreen].bounds.size.width;
    CGFloat width = secondary ? 172.0f : kCompactWidth;
    
    CGRect compactFrame = CGRectMake(
        (screenW - width) / 2.0f,
        kTopOffset,
        width,
        kCompactHeight
    );
    
    [DIAnimator fadeOutView:_expandedView completion:^(BOOL f) {
        self.expandedView.hidden = YES;
        [self.expandedView clearContent];
    }];
    
    [_compactView updateWithPrimaryContent:content secondaryContent:secondary];
    [DIAnimator animateView:self toFrame:compactFrame cornerRadius:kCompactRadius completion:^(BOOL f) {
        [DIAnimator fadeInView:self.compactView delay:0.0];
    }];
}

- (void)showExpandedWithContent:(DIActivityContent *)content {
    _islandState = DIIslandStateExpanded;
    
    CGFloat screenW   = _parentView ? _parentView.bounds.size.width : [UIScreen mainScreen].bounds.size.width;
    CGFloat expHeight = kExpandedHeight;
    
    if (content.type == DIActivityTypeMusic) {
        expHeight = 84.0f;
    }
    
    CGRect expandedFrame = CGRectMake(
        (screenW - kExpandedWidth) / 2.0f,
        kTopOffset,
        kExpandedWidth,
        expHeight
    );
    
    self.compactView.alpha = 0;
    
    _expandedView.frame  = CGRectMake(0, 0, kExpandedWidth, expHeight);
    _expandedView.hidden = NO;
    [_expandedView updateWithContent:content];
    
    [DIAnimator animateView:self toFrame:expandedFrame cornerRadius:kExpandedRadius completion:nil];
    [DIAnimator fadeInView:_expandedView delay:0.12];
    [DIAnimator pulseShadow:self];
}

- (void)hideIsland {
    [UIView animateWithDuration:0.25 animations:^{
        self.alpha = 0;
        self.transform = CGAffineTransformMakeScale(0.92f, 0.92f);
    }];
}

- (void)revealIsland {
    [UIView animateWithDuration:0.3
                          delay:0
         usingSpringWithDamping:0.8
          initialSpringVelocity:0.3
                        options:0
                     animations:^{
        self.alpha     = 1;
        self.transform = CGAffineTransformIdentity;
    } completion:nil];
}

#pragma mark - Gesture Handlers

- (void)handleTap:(UITapGestureRecognizer *)tap {
    [DIAnimator bounceTap:self];
    [self triggerHaptic];
    
    DIActivityContent *current = [DIActivityManager sharedInstance].currentContent;
    
    if (_islandState == DIIslandStateExpanded) {
        if (current && current.bundleIdentifier && current.bundleIdentifier.length > 0) {
            [self launchAppWithBundleID:current.bundleIdentifier];
        } else {
            [[DIActivityManager sharedInstance] collapseToCompact];
        }
    } else if (_islandState == DIIslandStateCompact) {
        if (current) {
            [[DIActivityManager sharedInstance] presentContent:current];
        }
    } else if (_islandState == DIIslandStateIdle) {
        if (current) {
            [[DIActivityManager sharedInstance] presentContent:current];
        }
    }
}

- (void)handleLongPress:(UILongPressGestureRecognizer *)press {
    if (press.state == UIGestureRecognizerStateBegan) {
        [DIAnimator bounceTap:self];
        [self triggerHaptic];
        
        DIActivityContent *current = [DIActivityManager sharedInstance].currentContent;
        if (current && _islandState != DIIslandStateExpanded) {
            [[DIActivityManager sharedInstance] presentContent:current];
        }
    }
}

- (void)handleSwipeDown:(UISwipeGestureRecognizer *)swipe {
    DIActivityContent *current = [DIActivityManager sharedInstance].currentContent;
    if (current && _islandState != DIIslandStateExpanded) {
        [DIAnimator bounceTap:self];
        [self triggerHaptic];
        [[DIActivityManager sharedInstance] presentContent:current];
    }
}

- (void)handleSwipeCollapse:(UISwipeGestureRecognizer *)swipe {
    [self triggerHaptic];
    if (_islandState == DIIslandStateExpanded) {
        [[DIActivityManager sharedInstance] collapseToCompact];
    } else if (_islandState == DIIslandStateCompact) {
        [self showIdle];
    }
}

- (void)triggerHaptic {
    if (@available(iOS 10, *)) {
        if ([DIPreferencesManager sharedInstance].hapticFeedback) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
                initWithStyle:UIImpactFeedbackStyleLight];
            [gen impactOccurred];
        }
    }
}

- (void)launchAppWithBundleID:(NSString *)bundleID {
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        SEL launchSel = NSSelectorFromString(@"launchApplicationWithIdentifier:suspended:");
        if ([app respondsToSelector:launchSel]) {
            NSMethodSignature *sig = [app methodSignatureForSelector:launchSel];
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
            [inv setTarget:app];
            [inv setSelector:launchSel];
            [inv setArgument:&bundleID atIndex:2];
            BOOL suspended = NO;
            [inv setArgument:&suspended atIndex:3];
            [inv invoke];
        }
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] launchApp error: %@", e);
    }
}

#pragma mark - DIActivityManagerDelegate

- (void)activityManager:(id)manager
      didUpdateContent:(DIActivityContent *)content
                 state:(DIIslandState)state {
    [self activityManager:manager didUpdateContent:content secondaryContent:nil state:state];
}

- (void)activityManager:(id)manager
      didUpdateContent:(DIActivityContent *)content
      secondaryContent:(DIActivityContent *)secondary
                 state:(DIIslandState)state {
    if (state == DIIslandStateExpanded) {
        [self showExpandedWithContent:content];
    } else if (state == DIIslandStateCompact) {
        [self showCompactWithContent:content secondaryContent:secondary];
    } else {
        [self showIdle];
    }
}

- (void)activityManagerDidClearContent:(id)manager {
    [self showIdle];
}

@end
