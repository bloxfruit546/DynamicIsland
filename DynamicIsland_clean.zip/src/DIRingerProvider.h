#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DIRingerProvider : NSObject

@property (nonatomic, readonly) BOOL isSilent;

+ (instancetype)sharedInstance;
- (void)startMonitoring;
- (void)stopMonitoring;
- (void)checkRingerState;
- (void)handleRingerMuted:(BOOL)muted;

@end
