#import "DICompactView.h"
#import <QuartzCore/QuartzCore.h>

// ── Equalizer Waveform View ─────────────────────────────────
@interface DIWaveformView : UIView
- (void)startAnimating;
- (void)stopAnimating;
@end

@implementation DIWaveformView {
    UIView *_bar1;
    UIView *_bar2;
    UIView *_bar3;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        CGFloat barW = 2.5f;
        CGFloat spacing = 2.0f;
        CGFloat h = frame.size.height;
        
        _bar1 = [[UIView alloc] initWithFrame:CGRectMake(0, (h - 10) / 2.0f, barW, 10)];
        _bar1.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        _bar1.layer.cornerRadius = 1.25f;
        [self addSubview:_bar1];
        
        _bar2 = [[UIView alloc] initWithFrame:CGRectMake(barW + spacing, (h - 16) / 2.0f, barW, 16)];
        _bar2.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        _bar2.layer.cornerRadius = 1.25f;
        [self addSubview:_bar2];
        
        _bar3 = [[UIView alloc] initWithFrame:CGRectMake((barW + spacing) * 2, (h - 8) / 2.0f, barW, 8)];
        _bar3.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        _bar3.layer.cornerRadius = 1.25f;
        [self addSubview:_bar3];
    }
    return self;
}

- (void)startAnimating {
    [self animateBar:_bar1 duration:0.42 minScale:0.35f maxScale:1.0f];
    [self animateBar:_bar2 duration:0.32 minScale:0.20f maxScale:1.0f];
    [self animateBar:_bar3 duration:0.50 minScale:0.45f maxScale:1.0f];
}

- (void)animateBar:(UIView *)bar duration:(NSTimeInterval)dur minScale:(CGFloat)minS maxScale:(CGFloat)maxS {
    [bar.layer removeAnimationForKey:@"waveformPulse"];
    CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"transform.scale.y"];
    anim.fromValue = @(minS);
    anim.toValue = @(maxS);
    anim.duration = dur;
    anim.autoreverses = YES;
    anim.repeatCount = HUGE_VALF;
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [bar.layer addAnimation:anim forKey:@"waveformPulse"];
}

- (void)stopAnimating {
    [_bar1.layer removeAnimationForKey:@"waveformPulse"];
    [_bar2.layer removeAnimationForKey:@"waveformPulse"];
    [_bar3.layer removeAnimationForKey:@"waveformPulse"];
}

@end

// ── DICompactView ───────────────────────────────────────────
@interface DICompactView ()
@property (nonatomic, strong) DIWaveformView *waveformView;
@property (nonatomic, strong) UIView         *callPulseDot;
@end

@implementation DICompactView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (void)setupViews {
    self.backgroundColor = [UIColor clearColor];
    self.clipsToBounds = YES;
    
    // Left app icon / album art
    _iconView = [[UIImageView alloc] initWithFrame:CGRectMake(7, 5, 20, 20)];
    _iconView.contentMode = UIViewContentModeScaleAspectFit;
    _iconView.clipsToBounds = YES;
    _iconView.layer.cornerRadius = 4;
    _iconView.hidden = YES;
    [self addSubview:_iconView];
    
    // Left symbol (emoji/unicode icon for timer, battery, etc.)
    _leftSymbolLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 4, 22, 22)];
    _leftSymbolLabel.font = [UIFont systemFontOfSize:14];
    _leftSymbolLabel.textAlignment = NSTextAlignmentCenter;
    _leftSymbolLabel.hidden = YES;
    [self addSubview:_leftSymbolLabel];
    
    // Green dot for active phone call
    _callPulseDot = [[UIView alloc] initWithFrame:CGRectMake(11, 10, 10, 10)];
    _callPulseDot.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
    _callPulseDot.layer.cornerRadius = 5;
    _callPulseDot.hidden = YES;
    [self addSubview:_callPulseDot];
    
    // Waveform on right (for music)
    _waveformView = [[DIWaveformView alloc] initWithFrame:CGRectMake(self.bounds.size.width - 24, 5, 16, 20)];
    _waveformView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    _waveformView.hidden = YES;
    [self addSubview:_waveformView];
    
    // Status text (center / left)
    _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(32, 6, 80, 18)];
    _statusLabel.textColor = [UIColor whiteColor];
    _statusLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    _statusLabel.textAlignment = NSTextAlignmentLeft;
    _statusLabel.hidden = YES;
    [self addSubview:_statusLabel];
    
    // Right text (e.g. countdown digits, battery percentage, call duration)
    _rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bounds.size.width - 70, 6, 62, 18)];
    _rightLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    _rightLabel.textColor = [UIColor whiteColor];
    _rightLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightBold];
    _rightLabel.textAlignment = NSTextAlignmentRight;
    _rightLabel.hidden = YES;
    [self addSubview:_rightLabel];
}

- (void)updateWithContent:(DIActivityContent *)content {
    [self resetAll];
    if (!content) return;
    
    switch (content.type) {
        case DIActivityTypeMusic: {
            if (content.artwork) {
                _iconView.image = content.artwork;
                _iconView.hidden = NO;
            } else {
                _leftSymbolLabel.text = @"🎵";
                _leftSymbolLabel.hidden = NO;
            }
            _waveformView.hidden = NO;
            [_waveformView startAnimating];
            break;
        }
        case DIActivityTypeTimer: {
            _leftSymbolLabel.text = @"⏱";
            _leftSymbolLabel.hidden = NO;
            
            _rightLabel.text = content.title;
            _rightLabel.textColor = [UIColor colorWithRed:1.0 green:0.62 blue:0.04 alpha:1.0]; // Orange
            _rightLabel.hidden = NO;
            break;
        }
        case DIActivityTypeCharging: {
            _leftSymbolLabel.text = @"⚡";
            _leftSymbolLabel.hidden = NO;
            
            _rightLabel.text = content.title;
            _rightLabel.textColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0]; // Battery green
            _rightLabel.hidden = NO;
            break;
        }
        case DIActivityTypeRinger: {
            _leftSymbolLabel.text = content.customState ? @"🔕" : @"🔔";
            _leftSymbolLabel.hidden = NO;
            
            _rightLabel.text = content.title;
            _rightLabel.textColor = content.customState ? [UIColor colorWithRed:1.0 green:0.23 blue:0.19 alpha:1.0] : [UIColor whiteColor];
            _rightLabel.hidden = NO;
            break;
        }
        case DIActivityTypeCall: {
            _callPulseDot.hidden = NO;
            [self pulseCallDot];
            
            _rightLabel.text = content.title;
            _rightLabel.textColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
            _rightLabel.hidden = NO;
            break;
        }
        case DIActivityTypeNotification: {
            if (content.icon) {
                _iconView.image = content.icon;
                _iconView.hidden = NO;
            }
            _statusLabel.text = content.title;
            _statusLabel.hidden = NO;
            break;
        }
        default:
            break;
    }
}

- (void)pulseCallDot {
    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    pulse.fromValue = @0.85f;
    pulse.toValue = @1.30f;
    pulse.duration = 0.6;
    pulse.autoreverses = YES;
    pulse.repeatCount = HUGE_VALF;
    pulse.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [_callPulseDot.layer addAnimation:pulse forKey:@"callPulse"];
}

- (void)showIcon:(UIImage *)icon statusText:(NSString *)text {
    [self resetAll];
    _iconView.image  = icon;
    _iconView.hidden = (icon == nil);
    _statusLabel.text   = text;
    _statusLabel.hidden = (text.length == 0);
}

- (void)showDefault {
    [self resetAll];
}

- (void)resetAll {
    _iconView.hidden        = YES;
    _leftSymbolLabel.hidden = YES;
    _callPulseDot.hidden    = YES;
    [_callPulseDot.layer removeAnimationForKey:@"callPulse"];
    
    _waveformView.hidden    = YES;
    [_waveformView stopAnimating];
    
    _statusLabel.hidden     = YES;
    _rightLabel.hidden      = YES;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _waveformView.frame = CGRectMake(self.bounds.size.width - 24, (self.bounds.size.height - 20) / 2.0f, 16, 20);
    _rightLabel.frame   = CGRectMake(self.bounds.size.width - 70, (self.bounds.size.height - 18) / 2.0f, 62, 18);
}

@end
