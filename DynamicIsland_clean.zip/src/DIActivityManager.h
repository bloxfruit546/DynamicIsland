#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, DIActivityType) {
    DIActivityTypeNone         = 0,
    DIActivityTypeNotification = 1,
    DIActivityTypeMusic        = 2,
    DIActivityTypeCall         = 3,
    DIActivityTypeTimer        = 4,
    DIActivityTypeCharging     = 5,
    DIActivityTypeRinger       = 6,
};

typedef NS_ENUM(NSInteger, DIIslandState) {
    DIIslandStateHidden   = -1,
    DIIslandStateIdle     =  0,
    DIIslandStateCompact  =  1,
    DIIslandStateExpanded =  2,
};

@interface DIActivityContent : NSObject

@property (nonatomic, assign) DIActivityType type;
@property (nonatomic, copy)   NSString  *title;
@property (nonatomic, copy)   NSString  *subtitle;
@property (nonatomic, copy)   NSString  *detail;
@property (nonatomic, strong) UIImage   *icon;
@property (nonatomic, strong) UIImage   *artwork;
@property (nonatomic, copy)   NSString  *bundleIdentifier;
@property (nonatomic, assign) BOOL       isOngoing;
@property (nonatomic, assign) NSTimeInterval duration;
@property (nonatomic, assign) CGFloat    progress;      // 0.0 to 1.0 (for timer or battery)
@property (nonatomic, assign) BOOL       customState;   // e.g. silent mode on/off

@end

@protocol DIActivityManagerDelegate <NSObject>
- (void)activityManager:(id)manager
      didUpdateContent:(DIActivityContent *)content
                 state:(DIIslandState)state;
@optional
- (void)activityManager:(id)manager
      didUpdateContent:(DIActivityContent *)content
      secondaryContent:(DIActivityContent *)secondary
                 state:(DIIslandState)state;
- (void)activityManagerDidClearContent:(id)manager;
@end

@interface DIActivityManager : NSObject

@property (nonatomic, weak)     id<DIActivityManagerDelegate> delegate;
@property (nonatomic, readonly) DIIslandState      currentState;
@property (nonatomic, readonly) DIActivityContent *currentContent;
@property (nonatomic, readonly) DIActivityContent *secondaryContent;

+ (instancetype)sharedInstance;
- (void)presentContent:(DIActivityContent *)content;
- (void)clearContent;
- (void)clearContentOfType:(DIActivityType)type;
- (void)collapseToCompact;

@end
