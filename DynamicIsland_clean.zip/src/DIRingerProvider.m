#import "DIRingerProvider.h"
#import "DIActivityManager.h"
#import "DIPreferencesManager.h"
#import <notify.h>

@interface DIRingerProvider ()
@property (nonatomic, assign) BOOL isSilent;
@property (nonatomic, assign) int ringerNotifyToken;
@end

static void RingerStateCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    [[DIRingerProvider sharedInstance] checkRingerState];
}

@implementation DIRingerProvider

+ (instancetype)sharedInstance {
    static DIRingerProvider *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isSilent = NO;
        _ringerNotifyToken = NOTIFY_TOKEN_INVALID;
    }
    return self;
}

- (void)startMonitoring {
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        RingerStateCallback,
        CFSTR("com.apple.springboard.ringerstate"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    
    notify_register_dispatch("com.apple.springboard.ringerstate", &_ringerNotifyToken, dispatch_get_main_queue(), ^(int token) {
        uint64_t state = 0;
        notify_get_state(token, &state);
        [self handleRingerMuted:(state == 0)];
    });
}

- (void)stopMonitoring {
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.apple.springboard.ringerstate"), NULL);
    if (_ringerNotifyToken != NOTIFY_TOKEN_INVALID) {
        notify_cancel(_ringerNotifyToken);
        _ringerNotifyToken = NOTIFY_TOKEN_INVALID;
    }
}

- (void)checkRingerState {
    uint64_t state = 0;
    if (_ringerNotifyToken != NOTIFY_TOKEN_INVALID) {
        notify_get_state(_ringerNotifyToken, &state);
        [self handleRingerMuted:(state == 0)];
    }
}

- (void)handleRingerMuted:(BOOL)muted {
    if (![DIPreferencesManager sharedInstance].isEnabled) return;
    if (![DIPreferencesManager sharedInstance].showRinger) return;
    
    _isSilent = muted;
    
    DIActivityContent *content = [[DIActivityContent alloc] init];
    content.type        = DIActivityTypeRinger;
    content.isOngoing   = NO;
    content.customState = muted;
    content.title       = muted ? @"Silent" : @"Ring";
    content.subtitle    = muted ? @"Mute" : @"Sound";
    
    [[DIActivityManager sharedInstance] presentContent:content];
}

- (void)dealloc {
    [self stopMonitoring];
}

@end
