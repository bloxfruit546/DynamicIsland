#import "DIActivityManager.h"
#import "DIPreferencesManager.h"

@implementation DIActivityContent
@end

@interface DIActivityManager ()
@property (nonatomic, strong) DIActivityContent *currentContent;
@property (nonatomic, strong) DIActivityContent *secondaryContent;
@property (nonatomic, strong) DIActivityContent *musicContent;
@property (nonatomic, strong) DIActivityContent *timerContent;
@property (nonatomic, strong) DIActivityContent *callContent;
@property (nonatomic, assign) DIIslandState      currentState;
@property (nonatomic, strong) NSTimer           *collapseTimer;
@end

@implementation DIActivityManager

+ (instancetype)sharedInstance {
    static DIActivityManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _currentState      = DIIslandStateIdle;
        _currentContent    = nil;
        _secondaryContent  = nil;
        _musicContent      = nil;
        _timerContent      = nil;
        _callContent       = nil;
    }
    return self;
}

- (void)presentContent:(DIActivityContent *)content {
    if (!content) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer = nil;
        
        // Cache ongoing activities
        if (content.isOngoing) {
            if (content.type == DIActivityTypeMusic) {
                self.musicContent = content;
            } else if (content.type == DIActivityTypeTimer) {
                self.timerContent = content;
            } else if (content.type == DIActivityTypeCall) {
                self.callContent = content;
            }
        }
        
        self.currentContent = content;
        [self resolveActiveContents];
        
        // Expand if transient or new primary
        self.currentState = DIIslandStateExpanded;
        [self notifyDelegate];
        
        // Auto-collapse transient events (Charging, Ringer, Notification)
        if (!content.isOngoing) {
            NSTimeInterval delay = [DIPreferencesManager sharedInstance].autoCollapseDelay;
            if (content.type == DIActivityTypeCharging) {
                delay = 2.5;
            } else if (content.type == DIActivityTypeRinger) {
                delay = 2.0;
            } else if (delay <= 0) {
                delay = 4.0;
            }
            
            self.collapseTimer = [NSTimer scheduledTimerWithTimeInterval:delay
                                                                  target:self
                                                                selector:@selector(autoCollapse)
                                                                userInfo:nil
                                                                 repeats:NO];
        }
    });
}

- (void)resolveActiveContents {
    // If current is transient (notification, battery, ringer), keep it as primary
    if (self.currentContent && !self.currentContent.isOngoing) {
        // Secondary is highest priority ongoing
        self.secondaryContent = self.timerContent ?: self.musicContent ?: self.callContent;
        return;
    }
    
    // Priority order for ongoing: Call > Timer > Music
    if (self.callContent) {
        self.currentContent = self.callContent;
        self.secondaryContent = self.timerContent ?: self.musicContent;
    } else if (self.timerContent) {
        self.currentContent = self.timerContent;
        self.secondaryContent = self.musicContent; // Music runs in background with waveform!
    } else if (self.musicContent) {
        self.currentContent = self.musicContent;
        self.secondaryContent = nil;
    } else {
        self.currentContent = nil;
        self.secondaryContent = nil;
    }
}

- (void)notifyDelegate {
    if ([self.delegate respondsToSelector:@selector(activityManager:didUpdateContent:secondaryContent:state:)]) {
        [self.delegate activityManager:self
                      didUpdateContent:self.currentContent
                      secondaryContent:self.secondaryContent
                                 state:self.currentState];
    } else {
        [self.delegate activityManager:self
                      didUpdateContent:self.currentContent
                                 state:self.currentState];
    }
}

- (void)clearContent {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer   = nil;
        self.currentContent   = nil;
        self.secondaryContent = nil;
        self.musicContent     = nil;
        self.timerContent     = nil;
        self.callContent      = nil;
        self.currentState     = DIIslandStateIdle;
        [self.delegate activityManagerDidClearContent:self];
    });
}

- (void)clearContentOfType:(DIActivityType)type {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (type == DIActivityTypeMusic) {
            self.musicContent = nil;
        } else if (type == DIActivityTypeTimer) {
            self.timerContent = nil;
        } else if (type == DIActivityTypeCall) {
            self.callContent = nil;
        }
        
        [self.collapseTimer invalidate];
        self.collapseTimer = nil;
        
        [self resolveActiveContents];
        
        if (self.currentContent) {
            self.currentState = DIIslandStateCompact;
            [self notifyDelegate];
        } else {
            self.currentState = DIIslandStateIdle;
            [self.delegate activityManagerDidClearContent:self];
        }
    });
}

- (void)collapseToCompact {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer = nil;
        
        [self resolveActiveContents];
        
        if (self.currentContent) {
            self.currentState = DIIslandStateCompact;
            [self notifyDelegate];
        } else {
            self.currentState = DIIslandStateIdle;
            [self.delegate activityManagerDidClearContent:self];
        }
    });
}

- (void)autoCollapse {
    [self collapseToCompact];
}

@end
