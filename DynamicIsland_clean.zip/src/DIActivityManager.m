#import "DIActivityManager.h"
#import "DIPreferencesManager.h"

@implementation DIActivityContent
@end

@interface DIActivityManager ()
@property (nonatomic, strong) DIActivityContent *currentContent;
@property (nonatomic, strong) DIActivityContent *backgroundOngoingContent; // Music or Timer
@property (nonatomic, assign) DIIslandState      currentState;
@property (nonatomic, strong) NSTimer           *collapseTimer;
@end

@implementation DIActivityManager

+ (instancetype)sharedInstance {
    static DIActivityManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _currentState   = DIIslandStateIdle;
        _currentContent = nil;
        _backgroundOngoingContent = nil;
    }
    return self;
}

- (void)presentContent:(DIActivityContent *)content {
    if (!content) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer = nil;
        
        // If this is an ongoing activity (Music/Timer/Call), save it as background ongoing
        if (content.isOngoing) {
            self.backgroundOngoingContent = content;
        }
        
        self.currentContent = content;
        self.currentState   = DIIslandStateExpanded;
        
        [self.delegate activityManager:self
                     didUpdateContent:content
                                state:DIIslandStateExpanded];
        
        // Auto-collapse transient events
        if (!content.isOngoing) {
            NSTimeInterval delay = [DIPreferencesManager sharedInstance].autoCollapseDelay;
            if (content.type == DIActivityTypeCharging) {
                delay = 2.5;
            } else if (content.type == DIActivityTypeRinger) {
                delay = 2.0;
            } else if (delay <= 0) {
                delay = 4.0;
            }
            
            self.collapseTimer = [NSTimer scheduledTimerWithTimeInterval:delay
                                                                  target:self
                                                                selector:@selector(autoCollapse)
                                                                userInfo:nil
                                                                 repeats:NO];
        }
    });
}

- (void)clearContent {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer  = nil;
        self.currentContent = nil;
        self.backgroundOngoingContent = nil;
        self.currentState   = DIIslandStateIdle;
        [self.delegate activityManagerDidClearContent:self];
    });
}

- (void)clearContentOfType:(DIActivityType)type {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.backgroundOngoingContent && self.backgroundOngoingContent.type == type) {
            self.backgroundOngoingContent = nil;
        }
        if (self.currentContent && self.currentContent.type == type) {
            [self.collapseTimer invalidate];
            self.collapseTimer = nil;
            self.currentContent = nil;
            
            // If another ongoing content is waiting, resume it
            if (self.backgroundOngoingContent) {
                self.currentContent = self.backgroundOngoingContent;
                self.currentState   = DIIslandStateCompact;
                [self.delegate activityManager:self
                             didUpdateContent:self.backgroundOngoingContent
                                        state:DIIslandStateCompact];
            } else {
                self.currentState = DIIslandStateIdle;
                [self.delegate activityManagerDidClearContent:self];
            }
        }
    });
}

- (void)collapseToCompact {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collapseTimer invalidate];
        self.collapseTimer = nil;
        
        // If current was transient and we have ongoing background, restore ongoing
        if (!self.currentContent.isOngoing && self.backgroundOngoingContent) {
            self.currentContent = self.backgroundOngoingContent;
        }
        
        if (self.currentContent) {
            self.currentState = DIIslandStateCompact;
            [self.delegate activityManager:self
                         didUpdateContent:self.currentContent
                                    state:DIIslandStateCompact];
        } else {
            self.currentState = DIIslandStateIdle;
            [self.delegate activityManagerDidClearContent:self];
        }
    });
}

- (void)autoCollapse {
    [self collapseToCompact];
}

@end
