#import <UIKit/UIKit.h>
#import "DIActivityManager.h"

@interface DICompactView : UIView

@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UILabel     *leftSymbolLabel;
@property (nonatomic, strong) UILabel     *statusLabel;
@property (nonatomic, strong) UILabel     *rightLabel;

- (void)updateWithContent:(DIActivityContent *)content;
- (void)showIcon:(UIImage *)icon statusText:(NSString *)text;
- (void)showDefault;

@end
