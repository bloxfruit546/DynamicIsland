#import "DIExpandedView.h"

// ── Notification subview ──────────────────────────────────────
@interface DINotificationSubview : UIView
@property (nonatomic, strong) UIImageView *appIconView;
@property (nonatomic, strong) UILabel     *appNameLabel;
@property (nonatomic, strong) UILabel     *titleLabel;
@property (nonatomic, strong) UILabel     *bodyLabel;
- (void)updateWithContent:(DIActivityContent *)content;
@end

@implementation DINotificationSubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _appIconView = [[UIImageView alloc] initWithFrame:CGRectMake(12, 12, 28, 28)];
        _appIconView.layer.cornerRadius = 6;
        _appIconView.clipsToBounds = YES;
        _appIconView.backgroundColor = [UIColor darkGrayColor];
        [self addSubview:_appIconView];
        
        _appNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(48, 12, 160, 14)];
        _appNameLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
        _appNameLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
        [self addSubview:_appNameLabel];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(48, 28, 220, 16)];
        _titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
        _titleLabel.textColor = [UIColor whiteColor];
        [self addSubview:_titleLabel];
        
        _bodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 50, 256, 16)];
        _bodyLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
        _bodyLabel.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
        _bodyLabel.numberOfLines = 1;
        [self addSubview:_bodyLabel];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    _appIconView.image  = content.icon;
    _appNameLabel.text  = content.subtitle;  // app name
    _titleLabel.text    = content.title;
    _bodyLabel.text     = content.detail;
}
@end

// ── Music subview ─────────────────────────────────────────────
@interface DIMusicSubview : UIView
@property (nonatomic, strong) UIImageView *artworkView;
@property (nonatomic, strong) UILabel     *songLabel;
@property (nonatomic, strong) UILabel     *artistLabel;
@property (nonatomic, strong) UIView      *progressBar;
@property (nonatomic, strong) UIView      *progressTrack;
- (void)updateWithContent:(DIActivityContent *)content;
@end

@implementation DIMusicSubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _artworkView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 62, 62)];
        _artworkView.layer.cornerRadius = 8;
        _artworkView.clipsToBounds = YES;
        _artworkView.backgroundColor = [UIColor colorWithWhite:0.2 alpha:1.0];
        [self addSubview:_artworkView];
        
        _songLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 12, 196, 18)];
        _songLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightBold];
        _songLabel.textColor = [UIColor whiteColor];
        [self addSubview:_songLabel];
        
        _artistLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 32, 196, 14)];
        _artistLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
        _artistLabel.textColor = [UIColor colorWithWhite:0.65 alpha:1.0];
        [self addSubview:_artistLabel];
        
        // Progress track
        _progressTrack = [[UIView alloc] initWithFrame:CGRectMake(80, 54, 196, 3)];
        _progressTrack.backgroundColor = [UIColor colorWithWhite:0.3 alpha:1.0];
        _progressTrack.layer.cornerRadius = 1.5;
        [self addSubview:_progressTrack];
        
        // Progress bar
        _progressBar = [[UIView alloc] initWithFrame:CGRectMake(80, 54, 98, 3)];
        _progressBar.backgroundColor = [UIColor whiteColor];
        _progressBar.layer.cornerRadius = 1.5;
        [self addSubview:_progressBar];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    _artworkView.image = content.artwork;
    _songLabel.text    = content.title;
    _artistLabel.text  = content.subtitle;
}
@end

// ── Call subview ──────────────────────────────────────────────
@interface DICallSubview : UIView
@property (nonatomic, strong) UIView  *greenDot;
@property (nonatomic, strong) UILabel *callerLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) NSTimer *pulseTimer;
- (void)updateWithContent:(DIActivityContent *)content;
- (void)startPulse;
- (void)stopPulse;
@end

@implementation DICallSubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _greenDot = [[UIView alloc] initWithFrame:CGRectMake(14, 24, 12, 12)];
        _greenDot.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        _greenDot.layer.cornerRadius = 6;
        [self addSubview:_greenDot];
        
        _callerLabel = [[UILabel alloc] initWithFrame:CGRectMake(36, 12, 240, 22)];
        _callerLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        _callerLabel.textColor = [UIColor whiteColor];
        [self addSubview:_callerLabel];
        
        _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(36, 36, 240, 16)];
        _statusLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
        _statusLabel.textColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        [self addSubview:_statusLabel];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    _callerLabel.text = content.title;
    _statusLabel.text = content.subtitle;
    [self startPulse];
}

- (void)startPulse {
    [self stopPulse];
    _pulseTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                   target:self
                                                 selector:@selector(doPulse)
                                                 userInfo:nil
                                                  repeats:YES];
}

- (void)stopPulse {
    [_pulseTimer invalidate];
    _pulseTimer = nil;
}

- (void)doPulse {
    [UIView animateWithDuration:0.3
                     animations:^{ self.greenDot.transform = CGAffineTransformMakeScale(1.3f, 1.3f); }
                     completion:^(BOOL f) {
        [UIView animateWithDuration:0.3 animations:^{
            self.greenDot.transform = CGAffineTransformIdentity;
        }];
    }];
}

- (void)dealloc {
    [self stopPulse];
}
@end

// ── Timer Subview ─────────────────────────────────────────────
@interface DITimerSubview : UIView
@property (nonatomic, strong) UILabel *iconLabel;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIView  *progressBar;
@property (nonatomic, strong) UIView  *progressTrack;
- (void)updateWithContent:(DIActivityContent *)content;
@end

@implementation DITimerSubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _iconLabel = [[UILabel alloc] initWithFrame:CGRectMake(14, 12, 38, 38)];
        _iconLabel.text = @"⏱";
        _iconLabel.font = [UIFont systemFontOfSize:30];
        _iconLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_iconLabel];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 14, 210, 15)];
        _titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        _titleLabel.textColor = [UIColor colorWithWhite:0.65 alpha:1.0];
        [self addSubview:_titleLabel];
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 29, 210, 26)];
        _timeLabel.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold];
        _timeLabel.textColor = [UIColor colorWithRed:1.0 green:0.62 blue:0.04 alpha:1.0];
        [self addSubview:_timeLabel];
        
        _progressTrack = [[UIView alloc] initWithFrame:CGRectMake(14, 58, 262, 3)];
        _progressTrack.backgroundColor = [UIColor colorWithWhite:0.25 alpha:1.0];
        _progressTrack.layer.cornerRadius = 1.5;
        [self addSubview:_progressTrack];
        
        _progressBar = [[UIView alloc] initWithFrame:CGRectMake(14, 58, 262, 3)];
        _progressBar.backgroundColor = [UIColor colorWithRed:1.0 green:0.62 blue:0.04 alpha:1.0];
        _progressBar.layer.cornerRadius = 1.5;
        [self addSubview:_progressBar];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    _titleLabel.text = content.subtitle ?: @"Timer";
    _timeLabel.text  = content.title;
    
    CGFloat progress = content.progress;
    if (progress < 0) progress = 0;
    if (progress > 1) progress = 1;
    _progressBar.frame = CGRectMake(14, 58, 262 * progress, 3);
}

@end

// ── Battery Subview ───────────────────────────────────────────
@interface DIBatterySubview : UIView
@property (nonatomic, strong) UILabel *boltLabel;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *percentLabel;
@property (nonatomic, strong) UIView  *progressBar;
@property (nonatomic, strong) UIView  *progressTrack;
- (void)updateWithContent:(DIActivityContent *)content;
@end

@implementation DIBatterySubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _boltLabel = [[UILabel alloc] initWithFrame:CGRectMake(14, 12, 38, 38)];
        _boltLabel.text = @"⚡";
        _boltLabel.font = [UIFont systemFontOfSize:28];
        _boltLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_boltLabel];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 14, 210, 15)];
        _titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        _titleLabel.textColor = [UIColor colorWithWhite:0.65 alpha:1.0];
        _titleLabel.text = @"Charging";
        [self addSubview:_titleLabel];
        
        _percentLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 29, 210, 26)];
        _percentLabel.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold];
        _percentLabel.textColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        [self addSubview:_percentLabel];
        
        _progressTrack = [[UIView alloc] initWithFrame:CGRectMake(14, 58, 262, 3.5)];
        _progressTrack.backgroundColor = [UIColor colorWithWhite:0.25 alpha:1.0];
        _progressTrack.layer.cornerRadius = 1.75;
        [self addSubview:_progressTrack];
        
        _progressBar = [[UIView alloc] initWithFrame:CGRectMake(14, 58, 262, 3.5)];
        _progressBar.backgroundColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1.0];
        _progressBar.layer.cornerRadius = 1.75;
        [self addSubview:_progressBar];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    _percentLabel.text = content.title;
    CGFloat pct = content.progress;
    if (pct < 0) pct = 0;
    if (pct > 1) pct = 1;
    _progressBar.frame = CGRectMake(14, 58, 262 * pct, 3.5);
}

@end

// ── Ringer Subview ────────────────────────────────────────────
@interface DIRingerSubview : UIView
@property (nonatomic, strong) UILabel *bellLabel;
@property (nonatomic, strong) UILabel *modeLabel;
@property (nonatomic, strong) UILabel *statusLabel;
- (void)updateWithContent:(DIActivityContent *)content;
@end

@implementation DIRingerSubview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        _bellLabel = [[UILabel alloc] initWithFrame:CGRectMake(18, 16, 40, 40)];
        _bellLabel.font = [UIFont systemFontOfSize:30];
        _bellLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_bellLabel];
        
        _modeLabel = [[UILabel alloc] initWithFrame:CGRectMake(68, 16, 200, 24)];
        _modeLabel.font = [UIFont systemFontOfSize:19 weight:UIFontWeightBold];
        [self addSubview:_modeLabel];
        
        _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(68, 40, 200, 16)];
        _statusLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        _statusLabel.textColor = [UIColor colorWithWhite:0.6 alpha:1.0];
        [self addSubview:_statusLabel];
    }
    return self;
}

- (void)updateWithContent:(DIActivityContent *)content {
    if (content.customState) {
        _bellLabel.text = @"🔕";
        _modeLabel.text = @"Silent";
        _modeLabel.textColor = [UIColor colorWithRed:1.0 green:0.23 blue:0.19 alpha:1.0];
        _statusLabel.text = @"Mute Switch ON";
    } else {
        _bellLabel.text = @"🔔";
        _modeLabel.text = @"Ring";
        _modeLabel.textColor = [UIColor whiteColor];
        _statusLabel.text = @"Mute Switch OFF";
    }
}

@end

// ── DIExpandedView (Main Container) ──────────────────────────
@interface DIExpandedView ()
@property (nonatomic, strong) DINotificationSubview *notifView;
@property (nonatomic, strong) DIMusicSubview         *musicView;
@property (nonatomic, strong) DICallSubview          *callView;
@property (nonatomic, strong) DITimerSubview         *timerView;
@property (nonatomic, strong) DIBatterySubview       *batteryView;
@property (nonatomic, strong) DIRingerSubview        *ringerView;
@end

@implementation DIExpandedView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        [self setupSubviews];
    }
    return self;
}

- (void)setupSubviews {
    _notifView = [[DINotificationSubview alloc] initWithFrame:self.bounds];
    _notifView.hidden = YES;
    [self addSubview:_notifView];
    
    _musicView = [[DIMusicSubview alloc] initWithFrame:self.bounds];
    _musicView.hidden = YES;
    [self addSubview:_musicView];
    
    _callView = [[DICallSubview alloc] initWithFrame:self.bounds];
    _callView.hidden = YES;
    [self addSubview:_callView];
    
    _timerView = [[DITimerSubview alloc] initWithFrame:self.bounds];
    _timerView.hidden = YES;
    [self addSubview:_timerView];
    
    _batteryView = [[DIBatterySubview alloc] initWithFrame:self.bounds];
    _batteryView.hidden = YES;
    [self addSubview:_batteryView];
    
    _ringerView = [[DIRingerSubview alloc] initWithFrame:self.bounds];
    _ringerView.hidden = YES;
    [self addSubview:_ringerView];
}

- (void)updateWithContent:(DIActivityContent *)content {
    [self hideAllSubviews];
    if (!content) return;
    
    switch (content.type) {
        case DIActivityTypeNotification:
            [_notifView updateWithContent:content];
            _notifView.hidden = NO;
            break;
        case DIActivityTypeMusic:
            [_musicView updateWithContent:content];
            _musicView.hidden = NO;
            break;
        case DIActivityTypeCall:
            [_callView updateWithContent:content];
            _callView.hidden = NO;
            break;
        case DIActivityTypeTimer:
            [_timerView updateWithContent:content];
            _timerView.hidden = NO;
            break;
        case DIActivityTypeCharging:
            [_batteryView updateWithContent:content];
            _batteryView.hidden = NO;
            break;
        case DIActivityTypeRinger:
            [_ringerView updateWithContent:content];
            _ringerView.hidden = NO;
            break;
        default:
            break;
    }
}

- (void)clearContent {
    [self hideAllSubviews];
    [_callView stopPulse];
}

- (void)hideAllSubviews {
    _notifView.hidden   = YES;
    _musicView.hidden   = YES;
    _callView.hidden    = YES;
    _timerView.hidden   = YES;
    _batteryView.hidden = YES;
    _ringerView.hidden  = YES;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _notifView.frame   = self.bounds;
    _musicView.frame   = self.bounds;
    _callView.frame    = self.bounds;
    _timerView.frame   = self.bounds;
    _batteryView.frame = self.bounds;
    _ringerView.frame  = self.bounds;
}

@end
