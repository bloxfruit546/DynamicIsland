#import "DITimerProvider.h"
#import "DIActivityManager.h"
#import "DIPreferencesManager.h"
#import <notify.h>

@interface DITimerProvider ()
@property (nonatomic, assign) BOOL isRunning;
@property (nonatomic, assign) NSTimeInterval remainingSeconds;
@property (nonatomic, assign) NSTimeInterval totalSeconds;
@property (nonatomic, strong) NSTimer *tickTimer;
@property (nonatomic, copy)   NSString *timerLabel;
- (void)syncWithSystemTimer;
@end

static void TimerChangedCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    [[DITimerProvider sharedInstance] syncWithSystemTimer];
}

@implementation DITimerProvider

+ (instancetype)sharedInstance {
    static DITimerProvider *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isRunning = NO;
        _remainingSeconds = 0;
        _totalSeconds = 0;
    }
    return self;
}

- (void)startMonitoring {
    // Listen to MobileTimer Darwin notifications
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("MTTimerManagerStateResetNotification"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("com.apple.mobiletimer.timer-changed"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    [self syncWithSystemTimer];
}

- (void)stopMonitoring {
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("MTTimerManagerStateResetNotification"), NULL);
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.apple.mobiletimer.timer-changed"), NULL);
    [self stopTickTimer];
}

- (void)syncWithSystemTimer {
    if (![DIPreferencesManager sharedInstance].isEnabled) return;
    if (![DIPreferencesManager sharedInstance].showTimer) return;
    
    @try {
        Class MTTimerManagerClass = NSClassFromString(@"MTTimerManager");
        if (!MTTimerManagerClass) return;
        
        id manager = nil;
        if ([MTTimerManagerClass respondsToSelector:@selector(sharedInstance)]) {
            manager = [MTTimerManagerClass performSelector:@selector(sharedInstance)];
        } else {
            manager = [[(id)MTTimerManagerClass alloc] init];
        }
        
        if (manager && [manager respondsToSelector:@selector(currentTimer)]) {
            id timer = [manager performSelector:@selector(currentTimer)];
            if (timer) {
                // State: 1 = Running, 2 = Paused, 3 = Reset/Dismissed
                NSInteger state = 0;
                if ([timer respondsToSelector:@selector(state)]) {
                    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:[timer methodSignatureForSelector:@selector(state)]];
                    [inv setTarget:timer];
                    [inv setSelector:@selector(state)];
                    [inv invoke];
                    [inv getReturnValue:&state];
                }
                
                if (state == 1) { // Running
                    NSTimeInterval remaining = 0;
                    NSTimeInterval duration = 0;
                    if ([timer respondsToSelector:@selector(remainingTime)]) {
                        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:[timer methodSignatureForSelector:@selector(remainingTime)]];
                        [inv setTarget:timer];
                        [inv setSelector:@selector(remainingTime)];
                        [inv invoke];
                        [inv getReturnValue:&remaining];
                    }
                    if ([timer respondsToSelector:@selector(duration)]) {
                        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:[timer methodSignatureForSelector:@selector(duration)]];
                        [inv setTarget:timer];
                        [inv setSelector:@selector(duration)];
                        [inv invoke];
                        [inv getReturnValue:&duration];
                    }
                    
                    if (remaining > 0) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self updateWithRemaining:remaining total:(duration > 0 ? duration : remaining)];
                        });
                        return;
                    }
                }
            }
        }
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] syncWithSystemTimer error: %@", e);
    }
}

- (void)startTimerWithDuration:(NSTimeInterval)seconds label:(NSString *)label {
    _totalSeconds = seconds;
    _remainingSeconds = seconds;
    _timerLabel = label ?: @"Timer";
    _isRunning = YES;
    
    [self startTickTimer];
    [self broadcastTimerState];
}

- (void)updateWithRemaining:(NSTimeInterval)remaining total:(NSTimeInterval)total {
    _remainingSeconds = remaining;
    _totalSeconds = (total > 0) ? total : remaining;
    _timerLabel = @"Timer";
    _isRunning = YES;
    
    [self startTickTimer];
    [self broadcastTimerState];
}

- (void)cancelTimer {
    _isRunning = NO;
    [self stopTickTimer];
    [[DIActivityManager sharedInstance] clearContentOfType:DIActivityTypeTimer];
}

- (void)startTickTimer {
    [self stopTickTimer];
    _tickTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                  target:self
                                                selector:@selector(tick)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)stopTickTimer {
    [_tickTimer invalidate];
    _tickTimer = nil;
}

- (void)tick {
    if (_remainingSeconds > 0) {
        _remainingSeconds -= 1.0;
        [self broadcastTimerState];
    } else {
        [self cancelTimer];
    }
}

- (void)broadcastTimerState {
    DIActivityContent *content = [[DIActivityContent alloc] init];
    content.type      = DIActivityTypeTimer;
    content.isOngoing = YES;
    
    NSInteger totalSec = (NSInteger)_remainingSeconds;
    NSInteger hours    = totalSec / 3600;
    NSInteger minutes  = (totalSec % 3600) / 60;
    NSInteger seconds  = totalSec % 60;
    
    NSString *timeStr = nil;
    if (hours > 0) {
        timeStr = [NSString stringWithFormat:@"%ld:%02ld:%02ld", (long)hours, (long)minutes, (long)seconds];
    } else {
        timeStr = [NSString stringWithFormat:@"%02ld:%02ld", (long)minutes, (long)seconds];
    }
    
    content.title    = timeStr;
    content.subtitle = _timerLabel ?: @"Timer";
    content.bundleIdentifier = @"com.apple.mobiletimer";
    content.progress = (_totalSeconds > 0) ? (CGFloat)(_remainingSeconds / _totalSeconds) : 0.0f;
    
    [[DIActivityManager sharedInstance] presentContent:content];
}

- (void)dealloc {
    [self stopMonitoring];
}

@end
