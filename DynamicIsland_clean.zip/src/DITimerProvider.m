#import "DITimerProvider.h"
#import "DIActivityManager.h"
#import "DIPreferencesManager.h"
#import <notify.h>
#import <dlfcn.h>

#define kDITimerStatePath @"/var/mobile/Library/Preferences/com.dev.dynamicisland.timer.plist"
#define kDITimerNotifyName "com.dev.dynamicisland/TimerChanged"

@interface DITimerProvider ()
@property (nonatomic, assign) BOOL isRunning;
@property (nonatomic, assign) NSTimeInterval remainingSeconds;
@property (nonatomic, assign) NSTimeInterval totalSeconds;
@property (nonatomic, strong) NSTimer *tickTimer;
@property (nonatomic, copy)   NSString *timerLabel;
@property (nonatomic, assign) int timerNotifyToken;
@end

static void TimerChangedCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[DITimerProvider sharedInstance] syncWithSystemTimer];
    });
}

@implementation DITimerProvider

+ (instancetype)sharedInstance {
    static DITimerProvider *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[self alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isRunning = NO;
        _remainingSeconds = 0;
        _totalSeconds = 0;
        _timerNotifyToken = NOTIFY_TOKEN_INVALID;
    }
    return self;
}

#pragma mark - Cross-Process Event Handling

+ (void)handleTimerEvent:(id)timer state:(NSInteger)state {
    if (!timer) return;
    
    @try {
        NSTimeInterval duration = 0;
        NSTimeInterval remaining = 0;
        NSDate *fireDate = nil;
        NSString *title = @"Timer";
        
        if ([timer respondsToSelector:@selector(duration)]) {
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:[timer methodSignatureForSelector:@selector(duration)]];
            [inv setTarget:timer];
            [inv setSelector:@selector(duration)];
            [inv invoke];
            [inv getReturnValue:&duration];
        }
        if ([timer respondsToSelector:@selector(remainingTime)]) {
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:[timer methodSignatureForSelector:@selector(remainingTime)]];
            [inv setTarget:timer];
            [inv setSelector:@selector(remainingTime)];
            [inv invoke];
            [inv getReturnValue:&remaining];
        }
        if ([timer respondsToSelector:@selector(fireDate)]) {
            fireDate = [timer performSelector:@selector(fireDate)];
        }
        if ([timer respondsToSelector:@selector(title)]) {
            title = [timer performSelector:@selector(title)];
        }
        
        NSTimeInterval fireTimestamp = 0;
        if (fireDate) {
            fireTimestamp = [fireDate timeIntervalSince1970];
        } else if (remaining > 0) {
            fireTimestamp = [NSDate date].timeIntervalSince1970 + remaining;
        } else if (duration > 0) {
            fireTimestamp = [NSDate date].timeIntervalSince1970 + duration;
            remaining = duration;
        }
        
        NSDictionary *dict = @{
            @"state": @(state),
            @"duration": @(duration),
            @"remaining": @(remaining),
            @"fireTimestamp": @(fireTimestamp),
            @"title": title ?: @"Timer"
        };
        [dict writeToFile:kDITimerStatePath atomically:YES];
        notify_post(kDITimerNotifyName);
        
        // If we are already running in SpringBoard, apply immediately
        NSString *proc = [[NSProcessInfo processInfo] processName];
        if ([proc isEqualToString:@"SpringBoard"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[DITimerProvider sharedInstance] applyTimerStateFromDict:dict];
            });
        }
    } @catch (NSException *e) {
        NSLog(@"[DynamicIsland] handleTimerEvent error: %@", e);
    }
}

+ (void)handleTimerDismissed {
    NSDictionary *dict = @{ @"state": @(3) };
    [dict writeToFile:kDITimerStatePath atomically:YES];
    notify_post(kDITimerNotifyName);
    
    NSString *proc = [[NSProcessInfo processInfo] processName];
    if ([proc isEqualToString:@"SpringBoard"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[DITimerProvider sharedInstance] cancelTimer];
        });
    }
}

#pragma mark - Monitoring & Sync (SpringBoard)

- (void)startMonitoring {
    // 1. Listen for our cross-process notification
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("com.dev.dynamicisland/TimerChanged"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    
    // 2. Listen for native system timer Darwin notifications
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("com.apple.mobiletimer.timer-changed"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("com.apple.mobiletimer-framework.MobileTimer.timer-changed"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("MTTimerManagerStateResetNotification"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        TimerChangedCallback,
        CFSTR("com.apple.mobiletimer.reset"),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    
    notify_register_dispatch(kDITimerNotifyName, &_timerNotifyToken, dispatch_get_main_queue(), ^(int token) {
        [[DITimerProvider sharedInstance] syncWithSystemTimer];
    });
    
    // Initial sync
    [self syncWithSystemTimer];
}

- (void)stopMonitoring {
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.dev.dynamicisland/TimerChanged"), NULL);
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.apple.mobiletimer.timer-changed"), NULL);
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.apple.mobiletimer-framework.MobileTimer.timer-changed"), NULL);
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("MTTimerManagerStateResetNotification"), NULL);
    CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CFSTR("com.apple.mobiletimer.reset"), NULL);
    
    if (_timerNotifyToken != NOTIFY_TOKEN_INVALID) {
        notify_cancel(_timerNotifyToken);
        _timerNotifyToken = NOTIFY_TOKEN_INVALID;
    }
    [self stopTickTimer];
}

- (void)syncWithSystemTimer {
    if (![DIPreferencesManager sharedInstance].isEnabled) return;
    if (![DIPreferencesManager sharedInstance].showTimer) return;
    
    // 1. Read from our shared timer state plist
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:kDITimerStatePath];
    if (dict) {
        [self applyTimerStateFromDict:dict];
        return;
    }
    
    // 2. Read fallback from MobileTimer preferences
    NSDictionary *mtPrefs = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.mobiletimer.plist"];
    if (mtPrefs && mtPrefs[@"Timer"]) {
        NSDictionary *timerInfo = mtPrefs[@"Timer"];
        NSDate *fireDate = timerInfo[@"FireTime"] ?: timerInfo[@"FireDate"];
        NSNumber *duration = timerInfo[@"TotalDuration"] ?: timerInfo[@"Duration"];
        if (fireDate && duration) {
            NSTimeInterval rem = [fireDate timeIntervalSince1970] - [NSDate date].timeIntervalSince1970;
            if (rem > 0) {
                [self updateWithRemaining:rem total:[duration doubleValue]];
                return;
            }
        }
    }
}

- (void)applyTimerStateFromDict:(NSDictionary *)dict {
    if (!dict) return;
    
    NSInteger state = [dict[@"state"] integerValue];
    NSTimeInterval duration = [dict[@"duration"] doubleValue];
    NSTimeInterval fireTimestamp = [dict[@"fireTimestamp"] doubleValue];
    NSString *title = dict[@"title"] ?: @"Timer";
    
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    NSTimeInterval remaining = (fireTimestamp > 0) ? (fireTimestamp - now) : [dict[@"remaining"] doubleValue];
    
    if (state == 1 && remaining > 0) {
        // Running
        _totalSeconds     = (duration > 0) ? duration : remaining;
        _remainingSeconds = remaining;
        _timerLabel       = title;
        _isRunning        = YES;
        
        [self startTickTimer];
        [self broadcastTimerState];
    } else if (state == 2 && remaining > 0) {
        // Paused
        _totalSeconds     = (duration > 0) ? duration : remaining;
        _remainingSeconds = remaining;
        _timerLabel       = title;
        _isRunning        = NO;
        
        [self stopTickTimer];
        [self broadcastTimerState];
    } else {
        // Dismissed / Canceled / Expired
        [self cancelTimer];
    }
}

- (void)startTimerWithDuration:(NSTimeInterval)seconds label:(NSString *)label {
    _totalSeconds     = seconds;
    _remainingSeconds = seconds;
    _timerLabel       = label ?: @"Timer";
    _isRunning        = YES;
    
    [self startTickTimer];
    [self broadcastTimerState];
}

- (void)updateWithRemaining:(NSTimeInterval)remaining total:(NSTimeInterval)total {
    _remainingSeconds = remaining;
    _totalSeconds     = (total > 0) ? total : remaining;
    _timerLabel       = @"Timer";
    _isRunning        = YES;
    
    [self startTickTimer];
    [self broadcastTimerState];
}

- (void)cancelTimer {
    _isRunning = NO;
    _remainingSeconds = 0;
    _totalSeconds = 0;
    [self stopTickTimer];
    [[DIActivityManager sharedInstance] clearContentOfType:DIActivityTypeTimer];
}

- (void)startTickTimer {
    [self stopTickTimer];
    _tickTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                  target:self
                                                selector:@selector(tick)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)stopTickTimer {
    [_tickTimer invalidate];
    _tickTimer = nil;
}

- (void)tick {
    if (_remainingSeconds > 1.0) {
        _remainingSeconds -= 1.0;
        [self broadcastTimerState];
    } else {
        [self timerDidFinish];
    }
}

- (void)timerDidFinish {
    _remainingSeconds = 0;
    _isRunning = NO;
    [self stopTickTimer];
    
    // Broadcast finished banner on Dynamic Island
    DIActivityContent *content = [[DIActivityContent alloc] init];
    content.type             = DIActivityTypeTimer;
    content.isOngoing        = NO; // Transient: alerts and auto-collapses
    content.title            = @"00:00";
    content.subtitle         = @"Hết giờ (Timer Done)";
    content.bundleIdentifier = @"com.apple.mobiletimer";
    content.progress         = 0.0f;
    
    [[DIActivityManager sharedInstance] presentContent:content];
    
    // Remove state file
    [[NSFileManager defaultManager] removeItemAtPath:kDITimerStatePath error:nil];
}

- (void)broadcastTimerState {
    DIActivityContent *content = [[DIActivityContent alloc] init];
    content.type             = DIActivityTypeTimer;
    content.isOngoing        = YES;
    
    NSInteger totalSec = (NSInteger)_remainingSeconds;
    NSInteger hours    = totalSec / 3600;
    NSInteger minutes  = (totalSec % 3600) / 60;
    NSInteger seconds  = totalSec % 60;
    
    NSString *timeStr = nil;
    if (hours > 0) {
        timeStr = [NSString stringWithFormat:@"%ld:%02ld:%02ld", (long)hours, (long)minutes, (long)seconds];
    } else {
        timeStr = [NSString stringWithFormat:@"%02ld:%02ld", (long)minutes, (long)seconds];
    }
    
    content.title            = timeStr;
    content.subtitle         = _timerLabel ?: @"Timer";
    content.bundleIdentifier = @"com.apple.mobiletimer";
    content.progress         = (_totalSeconds > 0) ? (CGFloat)(_remainingSeconds / _totalSeconds) : 0.0f;
    
    [[DIActivityManager sharedInstance] presentContent:content];
}

- (void)dealloc {
    [self stopMonitoring];
}

@end
