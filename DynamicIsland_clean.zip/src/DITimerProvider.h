#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DITimerProvider : NSObject

@property (nonatomic, readonly) BOOL isRunning;
@property (nonatomic, readonly) NSTimeInterval remainingSeconds;
@property (nonatomic, readonly) NSTimeInterval totalSeconds;

+ (instancetype)sharedInstance;
- (void)startMonitoring;
- (void)stopMonitoring;

- (void)startTimerWithDuration:(NSTimeInterval)seconds label:(NSString *)label;
- (void)updateWithRemaining:(NSTimeInterval)remaining total:(NSTimeInterval)total;
- (void)syncWithSystemTimer;
- (void)cancelTimer;

@end
