#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DIBatteryProvider : NSObject

@property (nonatomic, readonly) BOOL isCharging;
@property (nonatomic, readonly) NSInteger batteryPercentage;

+ (instancetype)sharedInstance;
- (void)startMonitoring;
- (void)stopMonitoring;

@end
